self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "723d05b04bac18d6d17dd0be67a69faa",
    "url": "/index.html"
  },
  {
    "revision": "c7aeb8a213263aa91549",
    "url": "/static/js/2.d90a6726.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.d90a6726.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a4da16943809d0685560",
    "url": "/static/js/3.10db5e61.chunk.js"
  },
  {
    "revision": "058b6ec8635501b5b9e7",
    "url": "/static/js/main.c26f9702.chunk.js"
  },
  {
    "revision": "3f5de9bbd9fdf18d6d86",
    "url": "/static/js/runtime-main.ca3aa963.js"
  },
  {
    "revision": "2b50607c11d9911374bf38bb229d962c",
    "url": "/static/media/Archer.2b50607c.ttf"
  },
  {
    "revision": "116af611cbcd9e4bada60b4e700430c1",
    "url": "/static/media/AvenirLight.116af611.ttf"
  },
  {
    "revision": "63137a821976b7fdfcf941ab1528cb19",
    "url": "/static/media/Helvetica.63137a82.ttf"
  },
  {
    "revision": "07eedf76537449d9e77ebf51398065d7",
    "url": "/static/media/TescoModern.07eedf76.ttf"
  }
]);