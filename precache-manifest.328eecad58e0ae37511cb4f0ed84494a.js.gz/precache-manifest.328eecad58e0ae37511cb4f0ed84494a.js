self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b46c105a2e067ac89d9bd774cfe27ff4",
    "url": "/index.html"
  },
  {
    "revision": "0fb96e8340d5ad80020a",
    "url": "/static/js/2.5ed6701b.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.5ed6701b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "33df533615411e123485",
    "url": "/static/js/3.be2a613e.chunk.js"
  },
  {
    "revision": "d43734e563f449a3eed0",
    "url": "/static/js/main.f7713b45.chunk.js"
  },
  {
    "revision": "53faa89763ef8a2ea2fc",
    "url": "/static/js/runtime-main.44eb93ce.js"
  },
  {
    "revision": "2b50607c11d9911374bf38bb229d962c",
    "url": "/static/media/Archer.2b50607c.ttf"
  },
  {
    "revision": "116af611cbcd9e4bada60b4e700430c1",
    "url": "/static/media/AvenirLight.116af611.ttf"
  },
  {
    "revision": "63137a821976b7fdfcf941ab1528cb19",
    "url": "/static/media/Helvetica.63137a82.ttf"
  },
  {
    "revision": "07eedf76537449d9e77ebf51398065d7",
    "url": "/static/media/TescoModern.07eedf76.ttf"
  },
  {
    "revision": "7de2ad6bf23aa1afb86604f404103bf1",
    "url": "/static/media/TildaGrande.7de2ad6b.ttf"
  }
]);